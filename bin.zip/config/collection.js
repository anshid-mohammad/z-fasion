
module.exports={  
    USER_COLLECTION:'user',
    ADMIN_COLLECTION:'admin',
    PRODUCT_COLLECTION:'product',
    CART_COLLECTION:'cart',
    ORDER_COLLECTION:'order',
    TSHIRTS_COLLECTION:'tshirts'

   
  
}